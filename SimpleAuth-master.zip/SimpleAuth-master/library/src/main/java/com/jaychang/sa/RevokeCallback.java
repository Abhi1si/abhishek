package com.jaychang.sa;

public interface RevokeCallback {

  void onRevoked();

}
