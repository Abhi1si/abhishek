package com.example.agrismart.Model;

public class Rain {
}
